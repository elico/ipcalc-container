# ip subnet calculator
IPsubnet calculator IPv4 IPv6 in HTML 5 and css
originally created im 2006 in HTML4
.
multi-language

![IPsubnet_overview1](https://github.com/jmpep/IPsubnet/blob/master/pictures/ip-subnet-pitc1.png)
![IPsubnet_open_close_section](https://github.com/jmpep/IPsubnet/blob/master/pictures/ip-subnet-pitc2-open-close.png)
![IPsubnet_how_import](https://github.com/jmpep/IPsubnet/blob/master/pictures/ip-subnet-pitc3-import.png)
![IPsubnet_show_info](https://github.com/jmpep/IPsubnet/blob/master/pictures/ip-subnet-pitc4-info.png)
![IPsubnet_select_history](https://github.com/jmpep/IPsubnet/blob/master/pictures/ip-subnet-pitc5-history.png)
